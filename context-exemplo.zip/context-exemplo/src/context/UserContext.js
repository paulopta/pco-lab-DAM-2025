import React, { createContext, useState } from "react";

// Criando o contexto
export const UserContext = createContext();

// Criando o provider
export function UserProvider({ children }) {
  const [user, setUser] = useState({
    nome: "Convidado",
    logado: false,
  });

  function login(nome) {
    setUser({ nome, logado: true });
  }

  function logout() {
    setUser({ nome: "Convidado", logado: false });
  }

  return (
    <UserContext.Provider value={{ user, login, logout }}>
      {children}
    </UserContext.Provider>
  );
}
