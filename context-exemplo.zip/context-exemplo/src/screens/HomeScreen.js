import React, { useContext } from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { UserContext } from "../context/UserContext";

export default function HomeScreen() {
  const { user, login, logout } = useContext(UserContext);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>👤 Usuário: {user.nome}</Text>
      <Text>Status: {user.logado ? "Logado ✅" : "Deslogado ❌"}</Text>

      {user.logado ? (
        <Button title="Sair" onPress={logout} />
      ) : (
        <Button title="Entrar" onPress={() => login("Paulo")} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  titulo: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
});
