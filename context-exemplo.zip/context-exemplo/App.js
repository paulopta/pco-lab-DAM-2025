import React from "react";
import { SafeAreaView, StyleSheet } from "react-native";
import { UserProvider } from "./src/context/UserContext";
import HomeScreen from "./src/screens/HomeScreen";

export default function App() {
  return (
    <UserProvider>
      <SafeAreaView style={styles.container}>
        <HomeScreen />
      </SafeAreaView>
    </UserProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "center",
  },
});
