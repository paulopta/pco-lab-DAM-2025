import React, { useState } from 'react';
import { View, Button, StyleSheet, Alert, Text } from 'react-native';
import { Audio } from 'expo-av';

// URL de um som de notificação (Exemplo)

const SOUND_URI = 'https://palcocdn.akamaized.net/e/4/6/5/hungriahiphop-amor-e-fe-a4c807bb.mp3';

export default function AudioPlayerExample() {
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);

  // 1. Carregar e Reproduzir o Áudio
  async function playSound() {
    if (loading) return;
    setLoading(true);

    try {
      // Se já houver um objeto de som, apenas o reproduz
      if (sound) {
        await sound.replayAsync();
        setIsPlaying(true);
        setLoading(false);
        return;
      }

      // 1.1 Configuração da Categoria de Áudio (Importante para Android/iOS)
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true, // Permite tocar mesmo no modo silêncio no iOS
        shouldDuckAndroid: true,
        staysActiveInBackground: false,
        playThroughEarpieceAndroid: false,
      });

      // 1.2 Carrega o som
      const { sound } = await Audio.Sound.createAsync(
        require('./assets/sounds/hungriahiphop.mp3'), // O arquivo deve estar na pasta /assets
        { shouldPlay: true }, // Começa a tocar imediatamente
        onPlaybackStatusUpdate
      );
      setSound(newSound);
      setIsPlaying(true);
      setLoading(false);

    } catch (error) {
      console.error('Erro ao tocar o som:', error);
      Alert.alert('Erro de Áudio', 'Não foi possível reproduzir o som.');
      setLoading(false);
    }
  }

  // Função chamada durante a reprodução para monitorar o status
  const onPlaybackStatusUpdate = (status) => {
    if (status.didJustFinish) {
      setIsPlaying(false);
    }
  };

  // 2. Parar a Reprodução
  async function stopSound() {
    if (sound) {
      await sound.stopAsync();
      setIsPlaying(false);
    }
  }
  
  // 3. Descarregar o Áudio (Limpeza)
  // Essencial para liberar memória e recursos nativos!
  React.useEffect(() => {
    return sound
      ? () => {
          console.log('Descarregando Áudio...');
          sound.unloadAsync();
        }
      : undefined;
  }, [sound]);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Reprodução de Áudio com expo-av</Text>
      <Text style={styles.status}>Status: {isPlaying ? 'Tocando...' : 'Parado'}</Text>
      
      <Button 
        title={isPlaying ? 'Pausar/Parar' : 'Tocar Som'} 
        onPress={isPlaying ? stopSound : playSound}
        disabled={loading}
        color={isPlaying ? 'red' : 'green'}
      />
      
      {loading && <Text style={styles.loading}>Carregando Áudio...</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  titulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  status: {
    fontSize: 16,
    marginBottom: 20,
  },
  loading: {
    marginTop: 10,
    color: '#888',
  }
});