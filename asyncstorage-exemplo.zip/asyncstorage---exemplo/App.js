import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [nome, setNome] = useState('');
  const [salvo, setSalvo] = useState('');

  // Função para salvar o dado
  const salvarNome = async () => {
    try {
      await AsyncStorage.setItem('@nomeUsuario', nome);
      setSalvo(nome);
      alert('Nome salvo com sucesso!');
    } catch (e) {
      console.error('Erro ao salvar:', e);
    }
  };

  // Função para ler o dado ao iniciar o app
  const lerNome = async () => {
    try {
      const valor = await AsyncStorage.getItem('@nomeUsuario');
      if (valor !== null) {
        setSalvo(valor);
      }
    } catch (e) {
      console.error('Erro ao ler:', e);
    }
  };

  // useEffect para ler o nome salvo ao iniciar
  useEffect(() => {
    lerNome();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Exemplo de AsyncStorage</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite seu nome"
        value={nome}
        onChangeText={setNome}
      />

      <Button title="Salvar Nome" onPress={salvarNome} />

      <Text style={styles.texto}>
        Nome salvo: {salvo ? salvo : 'Nenhum nome salvo ainda'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F5F5F5',
    padding: 20,
  },
  titulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#CCC',
    width: '80%',
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
  },
  texto: {
    marginTop: 20,
    fontSize: 16,
  },
});