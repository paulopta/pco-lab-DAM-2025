import AsyncStorage from '@react-native-async-storage/async-storage';

    const saveItem = async (key, value) => {
      try {
        await AsyncStorage.setItem(key, value);
      } catch (e) {
        // handle error
      }
    };

    const getItem = async (key) => {
      try {
        const value = await AsyncStorage.getItem(key);
        return value;
      } catch (e) {
        // handle error
      }
    };