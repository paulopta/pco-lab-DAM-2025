// hooks/useSettings.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useState, useEffect } from 'react';

export function useSettings() {
  const [fontSize, setFontSize] = useState(16);
  const [bgColor, setBgColor] = useState('#ffffff');
  const [fontColor, setFontColor] = useState('#000000');
  const [loading, setLoading] = useState(true);

  // Carregar configurações salvas
  useEffect(() => {
    async function loadSettings() {
      try {
        const settings = await AsyncStorage.getItem('@app_settings');
        if (settings) {
          const parsed = JSON.parse(settings);
          setFontSize(parsed.fontSize || 16);
          setBgColor(parsed.bgColor || '#ffffff');
          setFontColor(parsed.fontColor || '#000000');
        }
      } catch (error) {
        console.log('Erro ao carregar configurações:', error);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  // Salvar configurações
  async function saveSettings(newSettings) {
    try {
      await AsyncStorage.setItem('@app_settings', JSON.stringify(newSettings));
      setFontSize(newSettings.fontSize);
      setBgColor(newSettings.bgColor);
      setFontColor(newSettings.fontColor);
    } catch (error) {
      console.log('Erro ao salvar configurações:', error);
    }
  }

  return { fontSize, bgColor, fontColor, saveSettings, loading };
}
