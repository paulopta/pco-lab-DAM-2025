// components/ConfigScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';

export default function ConfigScreen({ currentSettings, onSave }) {
  const [fontSize, setFontSize] = useState(String(currentSettings.fontSize));
  const [bgColor, setBgColor] = useState(currentSettings.bgColor);
  const [fontColor, setFontColor] = useState(currentSettings.fontColor);

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontWeight: 'bold', marginBottom: 10 }}>Configurações</Text>

      <Text>Tamanho da Fonte:</Text>
      <TextInput
        value={fontSize}
        onChangeText={setFontSize}
        keyboardType="numeric"
        style={{ borderWidth: 1, marginBottom: 10, padding: 5 }}
      />

      <Text>Cor de Fundo (hex):</Text>
      <TextInput
        value={bgColor}
        onChangeText={setBgColor}
        style={{ borderWidth: 1, marginBottom: 10, padding: 5 }}
      />

      <Text>Cor da Fonte (hex):</Text>
      <TextInput
        value={fontColor}
        onChangeText={setFontColor}
        style={{ borderWidth: 1, marginBottom: 10, padding: 5 }}
      />

      <Button
        title="Salvar Configurações"
        onPress={() => {
          onSave({
            fontSize: parseInt(fontSize),
            bgColor,
            fontColor,
          });
        }}
      />
    </View>
  );
}
