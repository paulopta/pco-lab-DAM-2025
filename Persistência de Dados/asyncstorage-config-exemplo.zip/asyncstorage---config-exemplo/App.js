// App.js
import React, { useState } from 'react';
import { View, Text, Button, ActivityIndicator } from 'react-native';
import { useSettings } from './src/hooks/useSettings';
import ConfigScreen from './src/components/ConfigScreen';

export default function App() {
  const { fontSize, bgColor, fontColor, saveSettings, loading } = useSettings();
  const [showConfig, setShowConfig] = useState(false);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" />
        <Text>Carregando configurações...</Text>
      </View>
    );
  }

  if (showConfig) {
    return (
      <ConfigScreen
        currentSettings={{ fontSize, bgColor, fontColor }}
        onSave={(newSettings) => {
          saveSettings(newSettings);
          setShowConfig(false);
        }}
      />
    );
  }

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: bgColor,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ fontSize, color: fontColor, marginBottom: 20 }}>
        Texto de Exemplo
      </Text>
      <Button title="Abrir Configurações" onPress={() => setShowConfig(true)} />
    </View>
  );
}
