// hooks/useDatabase.js
import { useEffect, useState } from "react";
import * as SQLite from "expo-sqlite";

export function useDatabase() {
  const [db, setDb] = useState(null);

  useEffect(() => {
    async function initDb() {
      try {
        const database = await SQLite.openDatabaseAsync("meubanco.db");

        // Cria tabela se não existir
        await database.execAsync(`
          CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            concluida INT DEFAULT 0
          );
        `);

        setDb(database);
      } catch (error) {
        console.error("Erro ao inicializar DB:", error);
      }
    }

    initDb();
  }, []);

  // Executa INSERT, UPDATE, DELETE
  const executar = async (sql, params = []) => {
    if (!db) return;
    return await db.runAsync(sql, params);
  };

  // Executa SELECT (retorna linhas)
  const selecionar = async (sql, params = []) => {
    if (!db) return [];
    return await db.getAllAsync(sql, params);
  };

  return { executar, selecionar, db };
}
