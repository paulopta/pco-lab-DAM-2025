// hooks/useTarefas.js
import { useState, useEffect } from "react";
import { useDatabase } from "./useDatabase";

export function useTarefas() {
  const { executar, selecionar } = useDatabase();
  const [tarefas, setTarefas] = useState([]);

  // Carregar tarefas
  async function carregarTarefas() {
    const rows = await selecionar("SELECT * FROM tarefas ORDER BY id DESC");
    setTarefas(rows);
  }

  // Adicionar
  async function adicionarTarefa(titulo) {
    if (!titulo) return;
    await executar("INSERT INTO tarefas (titulo) VALUES (?)", [titulo]);
    await carregarTarefas();
  }

  // Concluir/Desmarcar
  async function alternarConcluida(id, statusAtual) {
    const novoStatus = statusAtual ? 0 : 1;
    await executar("UPDATE tarefas SET concluida = ? WHERE id = ?", [
      novoStatus,
      id,
    ]);
    await carregarTarefas();
  }

  // Excluir
  async function excluirTarefa(id) {
    await executar("DELETE FROM tarefas WHERE id = ?", [id]);
    await carregarTarefas();
  }

  useEffect(() => {
    carregarTarefas();
  }, []);

  return {
    tarefas,
    carregarTarefas,
    adicionarTarefa,
    alternarConcluida,
    excluirTarefa,
  };
}
