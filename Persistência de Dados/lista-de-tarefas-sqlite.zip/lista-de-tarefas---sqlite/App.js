import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  FlatList,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { useTarefas } from "./src/hooks/useTarefas";

export default function App() {
  const { tarefas, adicionarTarefa, alternarConcluida, excluirTarefa } = useTarefas();
  const [titulo, setTitulo] = useState("");

  function handleAdicionar() {
    adicionarTarefa(titulo);
    setTitulo("");
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>📋 Minhas Tarefas</Text>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={titulo}
          onChangeText={setTitulo}
          placeholder="Digite uma tarefa..."
        />
        <Button title="Adicionar" onPress={handleAdicionar} />
      </View>

      <FlatList
        data={tarefas}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <TouchableOpacity
              style={{ flex: 1 }}
              onPress={() => alternarConcluida(item.id, item.concluida)}
            >
              <Text
                style={[
                  styles.itemTexto,
                  item.concluida ? styles.itemConcluida : null,
                ]}
              >
                {item.titulo}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => excluirTarefa(item.id)}>
              <Text style={styles.botaoExcluir}>❌</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, marginTop: 40 },
  titulo: { fontSize: 22, fontWeight: "bold", marginBottom: 20 },
  inputContainer: { flexDirection: "row", marginBottom: 20 },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    marginRight: 10,
    padding: 8,
    borderRadius: 5,
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 5,
    padding: 10,
    backgroundColor: "#f9f9f9",
    borderRadius: 5,
  },
  itemTexto: { fontSize: 18 },
  itemConcluida: { textDecorationLine: "line-through", color: "gray" },
  botaoExcluir: { fontSize: 18, marginLeft: 10 },
});
