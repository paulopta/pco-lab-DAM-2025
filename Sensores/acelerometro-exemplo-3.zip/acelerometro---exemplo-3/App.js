// App.js
import React, { useEffect, useRef, useState } from "react";
import {
  View,
  StyleSheet,
  Dimensions,
  Animated,
  Text,
  TouchableOpacity,
} from "react-native";
import { Gyroscope } from "expo-sensors";

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");
const OBJ_SIZE = 80;
const FPS = 60; // para integração simples

export default function App() {
  // Animated position do objeto móvel (vermelho)
  const pos = useRef(new Animated.ValueXY({ x: 50, y: 150 })).current;

  // Estado de colisão
  const [collided, setCollided] = useState(false);

  // posição fixa do objeto alvo (azul)
  const target = useRef({ x: SCREEN_W / 2 - OBJ_SIZE / 2, y: SCREEN_H / 2 }).current;

  // Velocidade simulada (px/seg) atual — mantida em ref para não causar re-renders
  const velRef = useRef({ x: 0, y: 0 });

  // filtro simples (low-pass) para suavizar giroscópio
  const gyroFilterRef = useRef({ x: 0, y: 0 });

  // subscrição do giroscópio
  useEffect(() => {
    // ajustar a sensibilidade: quanto maior, maior a resposta do movimento
    const SENSITIVITY = 1200; // tune conforme preferir
    const ALPHA = 0.2; // fator do filtro low-pass (0..1)

    // taxa de atualização do gyroscope (ms)
    Gyroscope.setUpdateInterval(Math.round(1000 / FPS));

    const subscription = Gyroscope.addListener((data) => {
      // data: { x, y, z } -> rotação em rad/s em cada eixo
      // interpretação usada aqui:
      // - data.x -> rotação ao redor do eixo X (afeta movimento vertical)
      // - data.y -> rotação ao redor do eixo Y (afeta movimento horizontal)
      // Esses sinais podem precisar ser invertidos em alguns dispositivos.

      // aplicar filtro low-pass para suavizar
      gyroFilterRef.current.x =
        ALPHA * data.x + (1 - ALPHA) * gyroFilterRef.current.x;
      gyroFilterRef.current.y =
        ALPHA * data.y + (1 - ALPHA) * gyroFilterRef.current.y;

      // tratar como "velocidade" base (integrar numericamente)
      // aqui transformamos o rotationRate em velocidade px/s (escala arbitrária)
      velRef.current.x += -gyroFilterRef.current.y * SENSITIVITY / FPS;
      velRef.current.y += gyroFilterRef.current.x * SENSITIVITY / FPS;

      // aplicar leve damping para não acelerar indefinidamente
      velRef.current.x *= 0.98;
      velRef.current.y *= 0.98;
    });

    return () => subscription.remove();
  }, []);

  // loop de animação para aplicar velocidade à posição e checar colisão
  useEffect(() => {
    let mounted = true;
    const intervalMs = Math.round(1000 / FPS);

    const loop = () => {
      if (!mounted) return;

      // obter posição atual
      pos.flattenOffset();
      pos.x.stopAnimation((curX) => {
        pos.y.stopAnimation((curY) => {
          // nova posição pela integração simples: x += vx * dt
          const dt = 1 / FPS;
          let newX = curX + velRef.current.x * dt;
          let newY = curY + velRef.current.y * dt;

          // limites da tela (não sair da área visível)
          const minX = 0;
          const minY = 0;
          const maxX = SCREEN_W - OBJ_SIZE;
          const maxY = SCREEN_H - OBJ_SIZE;

          if (newX < minX) {
            newX = minX;
            velRef.current.x = 0;
          }
          if (newX > maxX) {
            newX = maxX;
            velRef.current.x = 0;
          }
          if (newY < minY) {
            newY = minY;
            velRef.current.y = 0;
          }
          if (newY > maxY) {
            newY = maxY;
            velRef.current.y = 0;
          }

          // aplicar diretamente a Animated.ValueXY
          pos.setValue({ x: newX, y: newY });

          // checar colisão AABB com alvo
          const collidedNow =
            newX < target.x + OBJ_SIZE &&
            newX + OBJ_SIZE > target.x &&
            newY < target.y + OBJ_SIZE &&
            newY + OBJ_SIZE > target.y;

          if (collidedNow && !collided) {
            // entrou em colisão — animar um "bounce" e marcar
            setCollided(true);
            // pequeno impulso contrário para efeito visual
            velRef.current.x *= -0.5;
            velRef.current.y *= -0.5;

            // bounce: sequencia rápida de escalas (usando Animated)
            Animated.sequence([
              Animated.timing(scaleAnim, {
                toValue: 1.12,
                duration: 80,
                useNativeDriver: true,
              }),
              Animated.timing(scaleAnim, {
                toValue: 1,
                duration: 150,
                useNativeDriver: true,
              }),
            ]).start();
          } else if (!collidedNow && collided) {
            setCollided(false);
          }

          // schedule next tick
          timeoutId = setTimeout(loop, intervalMs);
        });
      });
    };

    // animação de escala para bounce
    const scaleAnim = new Animated.Value(1);
    // precisamos expor scaleAnim dentro do scope de colisão — então movemos para ref
    // (mas para simplicidade aqui criamos um ref)
    // start loop
    let timeoutId = setTimeout(loop, intervalMs);

    return () => {
      mounted = false;
      clearTimeout(timeoutId);
    };
  }, [pos, target, collided]);

  // scaleAnim definida separadamente para usar no estilo (recriamos para o render)
  const scaleAnimRef = useRef(new Animated.Value(1)).current;

  // Para disparar bounce visual quando houver colisão, escutamos `collided`
  useEffect(() => {
    if (collided) {
      Animated.sequence([
        Animated.timing(scaleAnimRef, {
          toValue: 1.12,
          duration: 80,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnimRef, {
          toValue: 1,
          duration: 150,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [collided, scaleAnimRef]);

  // botão para resetar posição
  const reset = () => {
    velRef.current = { x: 0, y: 0 };
    Animated.spring(pos, {
      toValue: { x: 50, y: 150 },
      useNativeDriver: false,
    }).start();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Colisão com Giroscópio — Expo Go (SDK 54)</Text>

      {/* Target (azul/verde quando colidir) */}
      <View
        style={[
          styles.target,
          {
            left: target.x,
            top: target.y,
            backgroundColor: collided ? "green" : "blue",
          },
        ]}
      />

      {/* Observable object (vermelho) */}
      <Animated.View
        style={[
          styles.box,
          {
            transform: [
              { translateX: pos.x },
              { translateY: pos.y },
              { scale: scaleAnimRef },
            ],
          },
        ]}
      />

      <View style={styles.footer}>
        <TouchableOpacity style={styles.button} onPress={reset}>
          <Text style={styles.buttonText}>Resetar posição</Text>
        </TouchableOpacity>

        <Text style={styles.hint}>
          Dica: movimente / incline levemente o aparelho para controlar o quadrado.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f2f2f7" },
  title: {
    marginTop: 40,
    alignSelf: "center",
    fontWeight: "600",
    fontSize: 16,
  },
  target: {
    position: "absolute",
    width: OBJ_SIZE,
    height: OBJ_SIZE,
    borderRadius: 10,
  },
  box: {
    position: "absolute",
    width: OBJ_SIZE,
    height: OBJ_SIZE,
    backgroundColor: "crimson",
    borderRadius: 10,
    left: 0,
    top: 0,
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 20,
    right: 20,
    alignItems: "center",
  },
  button: {
    backgroundColor: "#0a84ff",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    marginBottom: 10,
  },
  buttonText: { color: "white", fontWeight: "600" },
  hint: { color: "#444", fontSize: 12 },
});
