import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, Button, Image } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

export default function TestCamera() {
  const [cameraType, setCameraType] = useState('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [capturedPhoto, setCapturedPhoto] = useState(null); // Estado para a foto tirada
  const cameraRef = useRef(null); // Referência para a câmera

  if (!permission) {
    return <Text>Requesting camera permission...</Text>;
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <Text style={styles.message}>We need your permission to show the camera</Text>
        <Button onPress={requestPermission} title="Grant permission" />
      </View>
    );
  }

  const toggleCameraType = () => {
    setCameraType((prevType) => (prevType === 'back' ? 'front' : 'back'));
    setCapturedPhoto(null); // Limpa a foto quando a câmera muda
  };

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const options = { quality: 0.5 }; // Opções para a foto
        const photo = await cameraRef.current.takePictureAsync(options);
        setCapturedPhoto(photo.uri); // Define a foto capturada
        console.log('Foto tirada:', photo.uri);
      } catch (error) {
        console.error('Erro ao tirar foto:', error);
      }
    }
  };

  const retakePhoto = () => {
    setCapturedPhoto(null); // Volta para a pré-visualização da câmera
  };

  return (
    <View style={styles.container}>
      {capturedPhoto ? (
        <Image source={{ uri: capturedPhoto }} style={styles.camera} />
      ) : (
        <CameraView
          style={styles.camera}
          facing={cameraType}
          ref={cameraRef} // Associa a referência à CameraView
        />
      )}
      <View style={styles.buttonContainer}>
        {capturedPhoto ? (
          <Button title="Tirar outra foto" onPress={retakePhoto} />
        ) : (
          <Button title="Tirar Foto" onPress={takePicture} />
        )}
        <Button title="Inverter Câmera" onPress={toggleCameraType} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 45,
    backgroundColor: 'black',
  },
  camera: {
    flex: 1,
  },
  message: {
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
});
