import React from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useAnimatedSensor,
  SensorType,
  withSpring,
} from 'react-native-reanimated';

export default function ReanimatedGyroscopeDemo() {
  const sensor = useAnimatedSensor(SensorType.GYROSCOPE, { interval: 20 }); // Intervalo de 20ms

  const animatedStyle = useAnimatedStyle(() => {
    // Os valores x, y, z representam a rotação em radianos por segundo
    // Usamos 'withSpring' para suavizar o movimento
    return {
      transform: [
        { translateX: withSpring(sensor.sensor.value.y * 150) },
        { translateY: withSpring(sensor.sensor.value.x * 150) },
      ],
    };
  });

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.object, animatedStyle]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  object: {
    width: 50,
    height: 50,
    backgroundColor: 'blue',
    borderRadius: 25,
  },
});