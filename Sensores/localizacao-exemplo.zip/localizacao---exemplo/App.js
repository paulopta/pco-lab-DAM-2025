import { useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import * as Location from 'expo-location';
import MapView, { Marker } from 'react-native-maps';


const App = () => {

const [location, setLocation] = useState(null);
const [errorMsg, setErrorMsg] = useState(null);

useEffect(() => {
  (async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      setErrorMsg('Permissão para acessar a localização foi negada');
      return;
    }

    let currentLocation = await Location.getCurrentPositionAsync({});
    setLocation(currentLocation);
  })();
}, []);

function calcularDistanciaGeografica(lat1, lon1, lat2, lon2) {
  const R = 6371; // Raio da Terra em km
  const PI = Math.PI;

  // Converter graus para radianos
  const radlat1 = lat1 * PI / 180;
  const radlat2 = lat2 * PI / 180;
  const radlon1 = lon1 * PI / 180;
  const radlon2 = lon2 * PI / 180;

  const deltaLat = radlat2 - radlat1;
  const deltaLon = radlon2 - radlon1;

  const a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(radlat1) * Math.cos(radlat2) *
    Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distância em km
  return distance;
}


if (location) { 

 return (

   <>
    <MapView
      style={{ width:500, height:500 }} // Defina o tamanho do mapa
      initialRegion={{
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      }}
    >
      <Marker
        coordinate={{
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        }}
        title=  "Sua Localização" 
      />
    </MapView>
    <View>
      <Text>Latitude: {location.coords.latitude}</Text>
      <Text>Longitude: {location.coords.longitude}</Text>
      <Text>Distância da Escola: {calcularDistanciaGeografica(location.coords.latitude, location.coords.longitude, -19.9529806, -44.0484167)}</Text>
    </View>
    </>
 );
 }
else if (errorMsg) {
  return (<Text>{errorMsg}</Text>); // Mostra a mensagem de erro
}
}

export default App;