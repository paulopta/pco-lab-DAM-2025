import {useState, useEffect} from 'react'
import { Appbar } from 'react-native-paper';
import {View, Text, StyleSheet} from 'react-native'
import { Button, TextInput } from 'react-native-paper';


const App = () => {

  const [cnpj,setCNPJ] = useState("");
  const [alias,setAlias] = useState("");

const consulta_cnpj = () =>{
  const url = `https://open.cnpja.com/office/${cnpj}`;
  fetch(url)
    .then((resp) => resp.json())
    .then((data) => {
      console.log(data);
      console.log(url);
      {data.code === 400 ? setAlias("O CNPJ informado é inválido") : setAlias("A razão social da empresa é: "+data["alias"])};
    })
};

  return(
     <View style={styles.content}>
    <Appbar.Header>
      <Appbar.Content title="Consulta CNPJ" />
    </Appbar.Header>
    <View>
      {alias != "" ?
      <>
        <Text> {alias}</Text>  
        <Button 
          icon="refresh" 
          mode="contained" 
          onPress={() => {setAlias("")}}
        >
         Nova Consulta
        </Button>
      </>  
      :
      <>
        <TextInput
          onChangeText={(text)=>setCNPJ(text)}
          value={cnpj}
          placeholder="CNPJ sem pontuação"
          keyboardType="numeric"
        />
        <Button 
          icon="magnify" 
          mode="contained" 
          onChangeText= {(text) => {setCNPJ(text)}} 
          onPress={() => {consulta_cnpj();}}
        >
          Buscar Dados
        </Button>
      </>  
      } 
    </View>
    </View>
  );

}

const styles = StyleSheet.create({
  content:{
    flex:1,
    justifyContent: 'center',    
    //alignItems:'center',
    gap: 10,
    padding: 35
  }
});

export default App;