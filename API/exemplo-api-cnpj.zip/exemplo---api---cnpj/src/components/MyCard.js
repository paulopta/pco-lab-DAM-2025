import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

// Componente do Card
const MyCard = ({ title, description, imageUrl }) => {
  return (
    <View style={styles.card}>
      {imageUrl && <Image source={{ uri: imageUrl }} style={styles.image} />}
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description}>{description}</Text>
      </View>
    </View>
  );
};

// Estilos do Card
const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    margin: 10,
    overflow: 'hidden', // Garante que a imagem não ultrapasse os cantos arredondados
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5, // Sombra para Android
  },
  image: {
    width: '100%',
    height: 150,
    resizeMode: 'cover', // Ajusta a imagem para cobrir o espaço
  },
  content: {
    padding: 15,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
  },
  description: {
    fontSize: 14,
    color: '#666',
  },
});

export default MyCard;