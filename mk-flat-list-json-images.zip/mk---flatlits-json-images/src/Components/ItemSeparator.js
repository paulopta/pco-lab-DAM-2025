import { View } from "react-native";

const ItemSeparator = () => {
  return (
    <View style={{ height: 1, width: "100%", backgroundColor: "#b4835f97" }} />
  );
}

export default ItemSeparator;