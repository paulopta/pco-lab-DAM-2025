import {Text} from 'react-native'

const CabecalhoLista = () => {

  return(
    <Text style={{ fontSize: 30, textAlign: "center",marginTop:20,fontWeight:'bold',textDecorationLine: 'underline' }}>
      Mortal Kombat 1 
    </Text>
  );

}

export default CabecalhoLista;