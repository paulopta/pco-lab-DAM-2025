import React, { useState, useEffect } from 'react';
import {Image, View, Text} from 'react-native';

const App = () => {
  
  const [randomDog, setRandomDog] = useState("");
  const [count, setCount] = useState(1);
  
  useEffect(() => {
    fetch("https://dog.ceo/api/breeds/image/random")
    .then((resp) => resp.json())
    .then((data) => {
      setRandomDog(data["message"]);
    })
  },[count]); // Array de dependências: o efeito é executado quando 'count' muda

  return randomDog ? (
    <View>
      <p>Você gerou {count} fotos aleatórias</p>
      <Image
        source={{uri: randomDog}}
        style = {{width:100, height:100}}
      />
      <button onClick={() => setCount(count + 1)}>
        Clique aqui e gere uma imagem
      </button>
    </View>
  ) : (
    <Text> Loading...</Text>
  );
};

export default App;