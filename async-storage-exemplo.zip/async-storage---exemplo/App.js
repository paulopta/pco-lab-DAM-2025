import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CONTADOR_KEY = '@MeuApp:contador';

const ContadorPersistente = () => {
  const [contador, setContador] = useState(0);

  // Carregar o contador ao iniciar o app
  useEffect(() => {
    carregarContador();
  }, []);

  const carregarContador = async () => {
    try {
      const valorSalvo = await AsyncStorage.getItem(CONTADOR_KEY);
      if (valorSalvo !== null) {
        setContador(parseInt(valorSalvo));
      }
    } catch (erro) {
      console.error('Erro ao carregar contador:', erro);
    }
  };

  const salvarContador = async (novoValor) => {
    try {
      await AsyncStorage.setItem(CONTADOR_KEY, novoValor.toString());
      setContador(novoValor);
    } catch (erro) {
      console.error('Erro ao salvar contador:', erro);
    }
  };

  const incrementar = () => {
    salvarContador(contador + 1);
  };

  const decrementar = () => {
    salvarContador(contador - 1);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Contador Persistente</Text>
      <Text style={styles.contador}>{contador}</Text>
      <View style={styles.botoesContainer}>
        <Button title="-" onPress={decrementar} color="#e74c3c" />
        <Button title="+" onPress={incrementar} color="#2ecc71" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  contador: {
    fontSize: 72,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#2c3e50',
  },
  botoesContainer: {
    flexDirection: 'row',
    width: 200,
    justifyContent: 'space-around',
  },
});

export default ContadorPersistente;
