import { Appbar } from 'react-native-paper';

const Titulo = (props) => {

  return(
    <Appbar.Header>
      <Appbar.Content title={props.titulo} />
    </Appbar.Header>
  );

}

export default Titulo;
