import {useState} from 'react';
import {View, Text} from 'react-native';
import { Button, TextInput } from 'react-native-paper';

{/* Components */}
import Titulo from './src/components/titulo/Titulo';

const App = () => {

const [distancia, setDistancia] = useState();
const [tempo, setTempo] = useState();
const [vm, setVm] = useState(0);

  return(
    <View>
      <Titulo titulo="Velocidade Média" />
      <TextInput
          label="Distância"
          value={distancia}
          onChangeText={text => setDistancia(text)}
      />
      <TextInput
          label="Tempo"
          value={tempo}
          onChangeText={text => setTempo(text)}
      />
      <Button 
          icon="magnify" 
          mode="contained" 
          onPress={() => {setVm(distancia/tempo);}}
      >
        Calcula Velocidade Média
      </Button>
      <Text>O velocidade média é de {vm}</Text>
    </View>
  );

}

export default App;
